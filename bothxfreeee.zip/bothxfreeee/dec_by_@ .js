Response;
Speed: 0.0061;
_Second_;
0.13310700003057718;
_miliseconds_;
Runtime: 38;
minutes;
22;
seconds;